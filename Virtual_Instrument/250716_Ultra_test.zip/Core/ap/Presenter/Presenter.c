#include "Presenter.h"

void Presenter_Init()
{

}
