#include "DFPLAYER_MINI.h"

//USB UART
#define DF_UART &huart1

#define Source      0x02  // TF CARD

//no need
//#define Previous_Key   GPIO_PIN_1
//#define Previous_Port  GPIOA
//#define Pause_Key      GPIO_PIN_2
//#define Pause_Port     GPIOA
//#define Next_Key       GPIO_PIN_3
//#define Next_Port      GPIOA

/*************************************** NO CHANGES AFTER THIS *************************************************/

int ispause =0;
int isplaying=1;


# define Start_Byte 0x7E
# define End_Byte   0xEF
# define Version    0xFF
# define Cmd_Len    0x06
# define Feedback   0x00    //If need for Feedback: 0x01,  No Feedback: 0

void Send_cmd (uint8_t cmd, uint8_t Parameter1, uint8_t Parameter2)
{
	uint16_t Checksum = Version + Cmd_Len + cmd + Feedback + Parameter1 + Parameter2;
	Checksum = 0-Checksum;

	uint8_t CmdSequence[10] = { Start_Byte, Version, Cmd_Len, cmd, Feedback, Parameter1, Parameter2, (Checksum>>8)&0x00ff, (Checksum&0x00ff), End_Byte};

	HAL_UART_Transmit(DF_UART, CmdSequence, 10, 100);


    char str[128];
    int len = sprintf(str, "Sent CMD: ");
    for (int i = 0; i < 10; i++) {
        len += sprintf(&str[len], "%02X ", CmdSequence[i]);
    }
    str[len++] = '\n';

    // 디버깅용 UART 포트로 출력 (예: huart1)
    HAL_UART_Transmit(&huart2, (uint8_t*)str, len, 100);
}

//start 0001 file
void DF_PlayFromStart(void)
{
  Send_cmd(0x03,0x00,0x01);
  HAL_Delay(200);
}

// select TF Card & Set volume (0x00~0x1E) --> make parameter
void DF_Init (uint8_t volume)
{
	Send_cmd(0x3F, 0x00, Source);
	HAL_Delay(500);
	Send_cmd(0x06, 0x00, volume);
	HAL_Delay(1000);
}

void DF_Next (void)
{
	Send_cmd(0x01, 0x00, 0x00);
	HAL_Delay(200);
}

void DF_Pause (void)
{
	Send_cmd(0x0E, 0, 0);
	HAL_Delay(200);
}

void DF_Previous (void)
{
	Send_cmd(0x02, 0, 0);
	HAL_Delay(200);
}

void DF_Playback (void)
{
	Send_cmd(0x0D, 0, 0);
	HAL_Delay(200);
}

//void Check_Key (void)
//{
//	if (HAL_GPIO_ReadPin(Pause_Port, Pause_Key))
//	{
//		while (HAL_GPIO_ReadPin(Pause_Port, Pause_Key));
//		if (isplaying)
//		{
//			ispause = 1;
//			isplaying = 0;
//			DF_Pause();
//		}
//
//		else if (ispause)
//		{
//			isplaying = 1;
//			ispause = 0;
//			DF_Playback();
//		}
//	}
//
//	if (HAL_GPIO_ReadPin(Previous_Port, Previous_Key))
//	{
//		while (HAL_GPIO_ReadPin(Previous_Port, Previous_Key));
//		DF_Previous();
//	}
//
//	if (HAL_GPIO_ReadPin(Next_Port, Next_Key))
//	{
//		while (HAL_GPIO_ReadPin(Next_Port, Next_Key));
//		DF_Next();
//	}
//}















