/*
 * Presenter.c
 *
 *  Created on: Jul 17, 2025
 *      Author: kccistc
 */
#include <Presenter.h>

void Presenter_Init()
{

}

void Presenter_Execute()
{

}
