/*
 * Presenter.h
 *
 *  Created on: Jul 17, 2025
 *      Author: kccistc
 */

#ifndef PRESENTER_INC_PRESENTER_H_
#define PRESENTER_INC_PRESENTER_H_

void Presenter_Init();
void Presenter_Execute();

#endif /* PRESENTER_INC_PRESENTER_H_ */
