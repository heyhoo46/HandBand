/*
 * Controller.h
 *
 *  Created on: Jul 17, 2025
 *      Author: kccistc
 */

#ifndef CONTROLLER_INC_CONTROLLER_H_
#define CONTROLLER_INC_CONTROLLER_H_

#include <CP_Model.h>
#include <LC_Model.h>
#include <TemporalFramDifferencing.h>

#endif /* CONTROLLER_INC_CONTROLLER_H_ */
