/*
 * TemporalFramDifferencing.h
 *
 *  Created on: Jul 17, 2025
 *      Author: kccistc
 */

#ifndef CONTROLLER_TEMPORALFRAMDIFFERENCING_H_
#define CONTROLLER_TEMPORALFRAMDIFFERENCING_H_

#include <vector.h>

Polar TemporalFramDifferencing(Point*, int);

#endif /* CONTROLLER_TEMPORALFRAMDIFFERENCING_H_ */
